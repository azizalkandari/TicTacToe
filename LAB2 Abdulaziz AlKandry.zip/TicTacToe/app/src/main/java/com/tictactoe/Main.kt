package com.tictactoe

import android.animation.AnimatorSet
import android.annotation.TargetApi
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.preference.PreferenceManager
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.*

class Main : AppCompatActivity() {
    var sp: SharedPreferences? = null
    var player1 = false
    var num_pressed = 0
    var isForeground = true
    var cells_values = IntArray(15)
    var cells: MutableList<ImageView> = ArrayList()
    var anim: AnimatorSet? = null
    var h = Handler()
    var single_game = false
    var comp_first = false
    var screen_width = 0
    var screen_height = 0
    var num_games = 0
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        sp = PreferenceManager.getDefaultSharedPreferences(this)
        show_main.run()

        findViewById<View>(R.id.all).setOnSystemUiVisibilityChangeListener { hide_navigation_bar() }

        for (i in 0..8) {
            val cell = ImageView(this)
            cell.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            cell.tag = i
            cell.isClickable = true
            (findViewById<View>(R.id.frame) as ViewGroup).addView(cell)
            cells.add(cell)

            cell.setOnTouchListener { v, event -> // cell click
                if (event.action == MotionEvent.ACTION_DOWN && v.isEnabled) CELL_CLICK(v)
                false
            }
        }
        SCALE()
    }

    // SCALE
    fun SCALE() {
        // text
        (findViewById<View>(R.id.txt_score) as TextView).setTextSize(TypedValue.COMPLEX_UNIT_PX, DpToPx(26f))

        // buttons text
        (findViewById<View>(R.id.btn_start1) as TextView).setTextSize(TypedValue.COMPLEX_UNIT_PX, DpToPx(26f))
        (findViewById<View>(R.id.btn_start2) as TextView).setTextSize(TypedValue.COMPLEX_UNIT_PX, DpToPx(26f))
        (findViewById<View>(R.id.btn_exit) as TextView).setTextSize(TypedValue.COMPLEX_UNIT_PX, DpToPx(26f))
    }

    // START
    fun START() {
        player1 = true
        num_pressed = 0
        findViewById<View>(R.id.game).visibility = View.VISIBLE
        findViewById<View>(R.id.main).visibility = View.GONE

        // screen size
        screen_width = findViewById<View>(R.id.all).width
        screen_height = findViewById<View>(R.id.all).height

        // cell size
        val cell_size = ((screen_width - DpToPx(20f)) / 3).toInt()

        // frame size and position
        findViewById<View>(R.id.frame).layoutParams.width = cell_size * 3
        findViewById<View>(R.id.frame).layoutParams.height = cell_size * 3

        // cells at start
        var x_pos = 0
        var y_pos = 0
        for (i in cells.indices) {
            cells_values[i] = 0
            cells[i].isEnabled = true
            cells[i].setImageResource(0)
            cells[i].layoutParams.width = cell_size
            cells[i].layoutParams.height = cell_size
            cells[i].x = (x_pos * cell_size).toFloat()
            cells[i].y = (y_pos * cell_size).toFloat()
            cells[i].scaleX = 1f
            cells[i].scaleY = 1f
            x_pos++
            if (x_pos == 3) {
                x_pos = 0
                y_pos++
            }
        }

        // computer go
        if (single_game) h.postDelayed(computer_go, 500)
    }

    // onClick
    fun onClick(v: View) {
        val ed = sp!!.edit()
        when (v.id) {
            R.id.btn_start1 -> {
                // single player game
                single_game = true
                comp_first = true
                START()
            }
            R.id.btn_start2 -> {
                // multiple player game
                single_game = false
                START()
            }
            R.id.btn_exit -> showExit()
        }
    }

    fun showExit() {
        val builder = MaterialAlertDialogBuilder(this@Main)
        builder.setTitle(this@Main.resources.getString(R.string.app_name))
        builder.setTitle(this@Main.resources.getString(R.string.msg_exit))
        val yes = this@Main.resources.getString(R.string.ac_yes)
        val cancel = this@Main.resources.getString(R.string.ac_cancle)
        builder.setPositiveButton(yes) { dialog, which -> finish() }
        builder.setNegativeButton(cancel) { dialog, which -> builder.setCancelable(true) }
        builder.show()
    }

    fun showQuit() {
        val builder = MaterialAlertDialogBuilder(this@Main)
        builder.setTitle(this@Main.resources.getString(R.string.app_name))
        builder.setTitle(this@Main.resources.getString(R.string.msg_quit))
        val yes = this@Main.resources.getString(R.string.ac_yes)
        val no = this@Main.resources.getString(R.string.ac_no)
        builder.setPositiveButton(yes) { dialog, which ->
            findViewById<View>(R.id.main).visibility = View.VISIBLE
            h.removeCallbacks(show_main)
            h.removeCallbacks(computer_go)
            if (anim != null) anim!!.cancel()
        }
        builder.setNegativeButton(no) { dialog, which -> builder.setCancelable(true) }
        builder.show()
    }

    // CELL_CLICK
    fun CELL_CLICK(v: View) {
        v.isEnabled = false


        // set cell icon
        if (player1) {
            (v as ImageView).setImageResource(R.drawable.player1)
            cells_values[Integer.valueOf(v.getTag().toString())] = 1
        } else {
            (v as ImageView).setImageResource(R.drawable.player2)
            cells_values[Integer.valueOf(v.getTag().toString())] = 2
        }
        player1 = !player1
        num_pressed++

        // check winner
        if (check_winner(1)) {
            // save result
            val ed = sp!!.edit()
            ed.putInt("player1", sp!!.getInt("player1", 0) + 1)
            ed.commit()
            STOP(1)
            return
        }
        if (check_winner(2)) {
            // save result
            val ed = sp!!.edit()
            ed.putInt("player2", sp!!.getInt("player2", 0) + 1)
            ed.commit()
            STOP(2)
            return
        }

        // no winner
        if (num_pressed == cells.size) {
            STOP(0)
            return
        }

        // computer go
        if (single_game && player1) h.postDelayed(computer_go, 500)
    }

    // computer_go
    var computer_go = Runnable {
        comp_first = false
    }

    // show_main
    var show_main = Runnable {
        findViewById<View>(R.id.game).visibility = View.GONE
        findViewById<View>(R.id.main).visibility = View.VISIBLE
    }

    // STOP
    fun STOP(result: Int) {
        num_games++

        // disable cells
        for (i in cells.indices) cells[i].isEnabled = false

        h.postDelayed(show_main, 500)

        if (num_games == 5) {
            num_games = 0
        }
    }

    // check_winner
    fun check_winner(player: Int): Boolean {
        if (cells_values[0] == player && cells_values[1] == player && cells_values[2] == player) {
            return true
        }
        if (cells_values[3] == player && cells_values[4] == player && cells_values[5] == player) {
            return true
        }
        if (cells_values[6] == player && cells_values[7] == player && cells_values[8] == player) {
            return true
        }
        if (cells_values[0] == player && cells_values[3] == player && cells_values[6] == player) {
            return true
        }
        if (cells_values[1] == player && cells_values[4] == player && cells_values[7] == player) {
            return true
        }
        if (cells_values[2] == player && cells_values[5] == player && cells_values[8] == player) {
            return true
        }
        if (cells_values[0] == player && cells_values[4] == player && cells_values[8] == player) {
            return true
        }
        if (cells_values[2] == player && cells_values[4] == player && cells_values[6] == player) {
            return true
        }
        return false
    }


    // DpToPx
    fun DpToPx(dp: Float): Float {
        return dp * Math.max(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels) / 500f
    }

    // hide_navigation_bar
    @TargetApi(Build.VERSION_CODES.KITKAT)
    fun hide_navigation_bar() {
        // fullscreen mode
        if (Build.VERSION.SDK_INT >= 19) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hide_navigation_bar()
    }

    override fun onResume() {
        super.onResume()
        isForeground = true
    }

    override fun onPause() {
        isForeground = false
        super.onPause()
    }

    override fun onBackPressed() {
        if (findViewById<View>(R.id.main).visibility == View.VISIBLE) {
            showExit()
        } else {
            showQuit()

        }
    }

    override fun onDestroy() {
        h.removeCallbacks(show_main)
        h.removeCallbacks(computer_go)
        if (anim != null) anim!!.cancel()
        super.onDestroy()
    }
}